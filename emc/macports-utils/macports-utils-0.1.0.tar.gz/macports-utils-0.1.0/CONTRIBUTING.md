Contributing to macports-utils
==============================

The easiest ways to contribute to `macports-utils` are:

  * Creating a new [issue].
  * Forking the repository, make your contribution and submit a pull request.

[issue]: https://github.com/emcrisostomo/macports-utils/issues/new

Coding Conventions and Style
----------------------------

Basic code style settings for Emacs are included in the script files as Emacs
file local variables.
